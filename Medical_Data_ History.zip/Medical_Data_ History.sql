select * from patients;
-- Q1. show first name, last name, and gender of patients whose gender is 'M'

select first_name, last_name, gender
from patients
 where gender = ' M ';
 
 -- Q2. show first name and last name of patient who do not have allergies 
 
 select first_name, last_name
 from patients
 where allergies is null;
 
 -- Q3. show first name of patients that start with letter 'C'
 
 select first_name
 from patients
 where first_name like 'C%';
 
 -- Q4. show first name and last name of patients that wegint within the range of 100 to 120
 
 select first_name, last_name
 from patients
 where weight between 100 and 120;
 
 -- Q5. update patients tables: if allergies is NULL, repalce it with 'NKA'
 
 UPDATE patients
 SET allergies = 'NKA'
 WHERE allergies IS NULL ;
 
 -- Q6. show first name and last name concatenated into one colume as full name
 
 select concat(first_name, ' ', last_name) as full_name
 from patients;
 
 -- Q7. show first name, last name, and full province name of each patient
 
 select p.first_name, p.last_name, pr.province_name
 from patients p
 join province_names pr on p.province_id = pr.province_id;
 
 -- Q8. show how many patients have a birth_date with 2010 as the birth year
 
 select count(*) as total_patients
 from patients
 where year(birth_date) = 2010;
 
 -- Q9. show first_name,last_name, and height of the patients with the greatest height
 
 select first_name, last_name, height
 FROM patients
 ORDER BY height DESC
 LIMIT 1;
 
 -- Q10 Show all columns for patients with patient_ids: 1,45,534,879,1000
 
 Select *
 from patients
 where patient_id in (1, 45, 534, 879, 1000);
 
-- Q11.show the total number of adimmissions

select count(*) AS total_adimissions
FROM admissions;

-- Q12.show all columns from adimissions where the patient was adimmitted and dischared on tge same day

select *
from admissions
where admission_date = discharge_date;

-- Q13 show the total number of admissions for patients_id 579
 
select count ( * ) as total_admissions
from admissions
where patients_id = 579;

-- Q14 show unique cities that are in province_id 'NS'

select distinct city
from patients
where province_id = 'NS';

-- Q15 find first_name,last_name and birth_date of patients with height > 160 and weight > 70

select first_name, last_name, birth_date
from patients
where height > 160 and weight > 70;

-- Q16 show unique birth years from patients, ordered ascending

select distinct year(birth_date) as birth_year
from patients
order by birth_year ASC;

-- Q17 show unique first names that occur only once in the patients table

select first_name
from patients
group by first_name
having count(first_name) = 1;

-- Q18 show patient_id and first_name where first_name starts and ends with 'S' and is at least 6 characters long

select patient_id, first_name
from patients
where first_name like 's%s'
and len(first_name) >= 6;

-- Q19 show patient_id,first_name from patients whose diagnosis is 'Dementia'

select p.patient_id, p.first_name, p.last_name
from patients p
jion admissions a on p.patient_id = a.patients_id
where a.diagnosis = 'Dementia';

-- Q20 Display every patient's first_name ordered by name length, then alphabetically

select first_name
from patients
order by len(first_name), first_name;

-- Q21 show total male and female patients in the same row

select 
sum(case when gender = 'M' then 1 else 0 end) as male_count
sum(case when gender = 'F' then 1 else 0 end) as female_count
from patients;

-- Q22 show total male and female patients in the same row (same as Q21)

select 
sum(case when gender = 'M' then 1 else 0 end) as male_count,
sum(case when gender = 'F' then 1 else 0 end) as female_count
from patients;

-- Q23. Show patient_id,diagnosis from admisstions where patients were admitted multiple times for the same diagnosis

select patient_id, diagnosis
from admissions
group by patients_id, diagnosis
having count(*) > 1;

-- Q24. show city and total no of patients, ordered fro most to least then by city nameascending

select city, count(*) as total_patients
from patients
group by city
order by total_patients desc, city asc;

-- Q25. shoe first name, last name and role of every person that is either a patient or a doctor

select first_name, last_name, 'patient' as role
from patients
union all
select first_name, last_name, 'doctor' as role
from doctors;

-- Q26.Show all allergies ordered by popularity, excluding NULL values

select allergies, count(*) as total_diagnosis
from patients
where allergies is not null
group by allergies
order by total_diagnosis desc;

-- Q27.Show first_name, last_name, and birth_date of patients born in the 1970s,sorted by earliest birth_date

select first_name, last_name, birth_date
from patients
where year(birth_date) between 1970 and 1979
order by birth_date asc;

-- Q28. Display full name as lastname,firstname ordered by first_name descending

select concat (upper(last_name), ",", lower(first_name)) as full_name
from patients
order by first-name desc;

-- Q29. S how province_id and sum of height where total sum >= 7000

select province_id, sum(height) as sum_height
from patients
group by province_id
having sum(height) >= 70000;

-- Q30. Show the difference between largest and smallest weight for patients with last name 'Maroni'

select max(weight) - min(weight) as weight_difference
from patients
where last_name = 'Maroni';

-- Q31. Show all days of the month and how amny admissions occured on that day

select day(admission_date) as day_of_month, count(*) as total_admissions
from admissions
group by (admission_date)
order by total_admissions desc;

-- Q32. Show patients grouped into weight groups, ordered descending

select
floor(weight / 10) * 10 as weight_group,
count(*) as total_patients
from patients
group by floor(weight / 10) * 10
order by weight_group desc;

-- Q33. Show patient_id, weight, height, isobese (BMI >= 30 = 1, else 0)

select 
patient_id,
weight,
height,
case
when weight / power(height / 100.0, 20 >= 30 then 1
else 0
end as isobese
from patients;

-- Q34. Show patient_id, first_id,last_name,and doctor's speciality for diagnosis 'Epilepsy' and doctor name 'Lisa'

select
p.patient_id, p.first_name, p.last_name, d.specialty
from patients p
join admissions a on p.patient_id = a.patient_id
join doctors d on a.attending_doctor_id = d.doctor_id
where a.diagnosis = 'Epilepsy'
and d.first_name = 'Lisa' ;
  

 
 


